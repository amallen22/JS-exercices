function fizzBuzz () {
  var myArr = []

  for (i = 1; i <= 100; i++) {
  	myArr.push(i)
  }
  return myArr
}

fizzBuzz()
